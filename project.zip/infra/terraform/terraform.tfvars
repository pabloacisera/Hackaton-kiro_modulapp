# ──────────────────────────────────────────────────────────────────────────────
# terraform.tfvars.example — Copy to terraform.tfvars and fill in real values
# NEVER commit terraform.tfvars (it's in .gitignore)
# ──────────────────────────────────────────────────────────────────────────────

# AWS region (must match your RDS region)
aws_region = "us-east-2"

# Project and environment
project_name = "modula"
environment  = "production"

# EC2 instance type
# t3.micro  = 2 vCPU, 1 GB RAM  — too small for 4 containers + build
# t3.small  = 2 vCPU, 2 GB RAM  — minimum viable (tight during builds)
# t3.medium = 2 vCPU, 4 GB RAM  — recommended (comfortable for builds)
instance_type = "t3.small"

# SSH key pair — must exist in AWS console BEFORE running terraform apply
# Create one: AWS Console → EC2 → Key Pairs → Create
key_pair_name = "modula-prod-key"

# Disk size in GB (Docker images + builds need space)
root_volume_size = 30

# CIDRs allowed to SSH (your IP). Leave empty to disable SSH (use SSM instead).
# Find your IP: curl ifconfig.me
ssh_allowed_cidrs = ["186.124.69.103/32"]

# Git repository to clone on the instance
app_repo_url = "https://github.com/pabloacisera/Hackaton-kiro_modulapp.git"
app_branch   = "main"

# Cloudflare Tunnel token (from Cloudflare Zero Trust dashboard)
# Create: Cloudflare Dashboard → Zero Trust → Networks → Tunnels → Create
cloudflare_tunnel_token = "eyJhIjoiN2QwOGRlNzQyNzFiNmViMDA4YmNkNzk1Njg2ZDI2YWQiLCJzIjoibUNKanhuWWZPbDMxTjJFejB0YmZZMXNrN2oyNnpqZ2tWcG83c1pQbWtKdz0iLCJ0IjoiZDZmYTRhNGYtZWI0ZC00N2Y0LTk3NTEtYjVjN2FkYjBmN2E5In0="

# If your RDS uses security group source-based rules (optional)
# rds_security_group_id = "sg-xxxxxxxxxxxxxxxxx"

# If using Option A (existing VPC where RDS lives):
# existing_vpc_id = "vpc-xxxxxxxxxxxxxxxxx"
