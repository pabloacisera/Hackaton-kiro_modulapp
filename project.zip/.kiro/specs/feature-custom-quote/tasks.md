# Tasks: Custom quote (Flow B)

- [x] TASK-quoteB-1: Migration for `quotes` table
  - Depends on: none
  - Assigned to: unassigned

- [x] TASK-quoteB-2: `Quote` domain entity + state machine with guards
  - Depends on: TASK-quoteB-1
  - Assigned to: unassigned
  - Done criterion: tests for invalid transitions being blocked

- [x] TASK-quoteB-3: `POST /quotes` endpoint with strict name/email/phone validation
  - Depends on: TASK-quoteB-2
  - Assigned to: unassigned

- [x] TASK-quoteB-4: Incomplete data discard path + admin notification (does not create `pending` state)
  - Depends on: TASK-quoteB-3
  - Assigned to: unassigned

- [x] TASK-quoteB-5: "Received, status pending" confirmation email to customer
  - Depends on: TASK-quoteB-3
  - Assigned to: unassigned

- [x] TASK-quoteB-6: `PATCH /quotes/:id/present` endpoint (admin quotes)
  - Depends on: TASK-quoteB-2
  - Assigned to: unassigned

- [x] TASK-quoteB-7: Signed one-time-use token generation (JWT) for accept/reject
  - Depends on: TASK-quoteB-6
  - Assigned to: unassigned

- [x] TASK-quoteB-8: Quote email with accept/reject buttons (deep link with token)
  - Depends on: TASK-quoteB-7
  - Assigned to: unassigned

- [x] TASK-quoteB-9: `GET /quotes/:id/accept` endpoint with token verification, expiration and single-use (transactional)
  - Depends on: TASK-quoteB-7
  - Assigned to: unassigned

- [x] TASK-quoteB-10: `GET /quotes/:id/reject` endpoint (same security criteria as accept)
  - Depends on: TASK-quoteB-7
  - Assigned to: unassigned

- [x] TASK-quoteB-11: Admin notification on rejection (for archiving)
  - Depends on: TASK-quoteB-10
  - Assigned to: unassigned

- [x] TASK-quoteB-12: Integration with payment-service to generate payment link on accept, with 24h `payment_deadline`
  - Depends on: TASK-quoteB-9
  - Assigned to: unassigned

- [x] TASK-quoteB-webhook: Webhook endpoint `POST /api/quotes/webhooks/payment-result` (called by payment-service)
  - Context: payment-service calls this endpoint to confirm payment result for a quote. Without this endpoint, the quote cannot transition from `payment_initiated` to `paid`.
  - Deliverable: `services/api-core/src/modules/quotes/interface/http/payment-result-webhook.controller.ts`
  - Depends on: TASK-quoteB-12
  - Assigned to: unassigned
  - Done criteria: validates webhook signature/origin (do not trust unvalidated requests), transitions `payment_initiated` → `paid` on success, sends confirmation email to customer, notifies admin via WebSocket. Returns 200 to payment-service.

- [x] TASK-quoteB-13: BullMQ job `quote-expiration-check` (48h without response)
  - Depends on: TASK-quoteB-6
  - Assigned to: unassigned

- [x] TASK-quoteB-14: BullMQ job `quote-payment-expiration-check` (24h without payment)
  - Depends on: TASK-quoteB-webhook
  - Assigned to: unassigned

- [x] TASK-quoteB-15: `PATCH /quotes/:id/archive` endpoint
  - Depends on: TASK-quoteB-2
  - Assigned to: unassigned

- [x] TASK-quoteB-16: Admin listing `GET /quotes` with filters/search/pagination
  - Depends on: TASK-quoteB-2
  - Assigned to: unassigned

- [x] TASK-quoteB-17: Landing UI — quote request form
  - Depends on: TASK-quoteB-3
  - Assigned to: unassigned

- [x] TASK-quoteB-18: Public accept/reject result pages (success, expired link, already processed)
  - Depends on: TASK-quoteB-9, TASK-quoteB-10
  - Assigned to: unassigned

- [x] TASK-quoteB-19: Admin UI — quoting screen (price + deadline form)
  - Depends on: TASK-quoteB-6
  - Assigned to: unassigned

- [x] TASK-quoteB-20: Admin notification on payment completion + delivery timer start
  - Depends on: TASK-quoteB-webhook, feature-order-delivery-schedule
  - Assigned to: unassigned

- [x] TASK-quoteB-test1: Unit tests for quote state machine and token logic
  - Context: Quote entity has complex state transitions and JWT token security. Must test: valid transitions (pending→quoted→accepted→paid, pending→quoted→rejected, pending→quoted→expired), invalid transitions blocked, token generation includes correct claims, token verification rejects expired/used tokens, token single-use prevents double-click.
  - Deliverable: `services/api-core/src/modules/quotes/**/*.spec.ts`
  - Depends on: TASK-quoteB-15
  - Assigned to: unassigned
  - Done criteria: unit.quote.stateMachine.validTransitionsAllowed, unit.quote.stateMachine.invalidTransitionsBlocked, unit.quote.token.generationIncludesQuoteIdAndExpiry, unit.quote.token.verificationRejectsExpired, unit.quote.token.verificationRejectsAlreadyUsed, unit.quote.token.atomicMarkPreventsDoubleClick. All pass.

- [x] TASK-quoteB-test2: Integration tests for full quote lifecycle
  - Context: validates complete flow: create quote → present → accept → payment initiation → payment webhook → paid. Also tests: incomplete data discard, expiration jobs, rejection flow. Uses Supertest with mocked payment-service and mocked BullMQ.
  - Deliverable: `services/api-core/src/modules/quotes/**/*.integration-spec.ts`
  - Depends on: TASK-quoteB-20
  - Assigned to: unassigned
  - Done criteria: integration.quote.create.missingFieldsCreatesDiscarded, integration.quote.create.validFieldsCreatesPending, integration.quote.present.movesToQuotedAndSendsEmail, integration.quote.accept.verifiesTokenAndMovesToAccepted, integration.quote.accept.expiredTokenReturnsError, integration.quote.accept.usedTokenReturnsCurrentState, integration.quote.reject.movesToRejected, integration.quote.expirationJob.movesExpiredQuotes, integration.quote.paymentExpirationJob.movesPaymentExpiredQuotes, integration.quote.archive.movesRejectedToArchived, integration.quote.webhook.paymentResultMovesToPaid, integration.quote.webhook.duplicateWebhookIsIdempotent. All pass.
